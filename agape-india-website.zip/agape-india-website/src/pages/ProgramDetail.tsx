import { Link, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { programs } from '../data/site'
import { useSeo } from '../lib/useSeo'
import { CtaBand, PageHero } from '../components/Blocks'
import DonationWidget from '../components/DonationWidget'
import { Reveal, SafeImage } from '../components/ui'
import NotFound from './NotFound'
import { purposeFor } from './Programs'

export default function ProgramDetail() {
  const { slug } = useParams()
  const index = programs.findIndex((p) => p.slug === slug)
  const p = programs[index]
  useSeo(p ? p.title : 'Program not found', p ? p.short : 'This program could not be found.')
  if (!p) return <NotFound />
  const next = programs[(index + 1) % programs.length]

  return (
    <>
      <PageHero eyebrow={`Program ${p.number}`} title={p.title} lede={p.short} image={p.image} imageAlt={p.imageAlt} />

      <section className="container-x section-y">
        <Link to="/programs" className="link-arrow mb-12 flex-row-reverse">
          All programs <ArrowLeft size={16} aria-hidden />
        </Link>
        <div className="grid gap-14 lg:grid-cols-[1.3fr_0.9fr] lg:gap-20">
          <div>
            <p className="font-display text-[clamp(1.4rem,2.4vw,1.9rem)] leading-snug text-ink">{p.summary}</p>
            <div className="mt-12 space-y-10">
              {p.body.map((b, i) => (
                <Reveal key={b.heading} delay={i * 60} className="grid gap-3 border-t border-line pt-8 sm:grid-cols-[3rem_1fr]">
                  <span className="font-display text-lg text-rust">{String(i + 1).padStart(2, '0')}</span>
                  <div>
                    <h2 className="display-sm">{b.heading}</h2>
                    <p className="mt-3 text-[1.05rem] text-muted">{b.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
            <SafeImage src={p.image} alt={p.imageAlt} className="mt-14 aspect-[16/9] lg:hidden" />
          </div>

          <aside className="lg:sticky lg:top-28 lg:self-start">
            <div className="rounded-[22px] border border-line bg-white p-6 shadow-[0_30px_60px_-40px_rgb(76_22_11/0.35)] sm:p-8">
              <h2 className="font-display text-2xl text-maroon-900">Support {p.title}</h2>
              <p className="mb-6 mt-2 text-sm text-muted">Your gift will be directed to this program.</p>
              <DonationWidget key={p.slug} initialPurpose={purposeFor(p.slug)} />
            </div>
          </aside>
        </div>
      </section>

      <section className="border-t border-line">
        <Link to={`/programs/${next.slug}`} className="group container-x flex items-center justify-between gap-6 py-12">
          <div>
            <p className="eyebrow">Next program</p>
            <p className="display-md mt-3 transition-colors group-hover:text-maroon-700">{next.title}</p>
          </div>
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-full border border-maroon-800 text-maroon-800 transition-colors group-hover:bg-maroon-800 group-hover:text-white">
            <ArrowRight size={22} aria-hidden />
          </span>
        </Link>
      </section>

      <CtaBand />
    </>
  )
}
